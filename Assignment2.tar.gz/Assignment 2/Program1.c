#include<stdio.h>
#include<stdlib.h>

int main(int argF, char*argV[])
{
char c;
FILE *inputfile,*outputfile;
int key = atoi(argV[1]);
inputfile = fopen(argV[2],"r");
outputfile = fopen (argV[3],"w");

while ((c=fgetc(inputfile))!=EOF){
char ch = (char)c;

if(ch>='A'&&ch<='Z')
ch+=32;

if(ch='a'&&ch<='z')
{ch=97+(ch+key-97)%26;
fprintf(outputfile,"%c",ch);
}
else
fprintf(outputfile, "%c",(char)c);
}
fclose(inputfile);
fclose(outputfile);
return 0;
}
