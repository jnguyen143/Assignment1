#include<stdio.h>
int Lab5(int n){
int i;
int ulimit=0;
for(i=1;i<n;i++){
ulimit*=10;
ulimit+=9;
}
int llimit=(1+ulimit)/10;

int mproduct=0;
for(i=ulimit;i>=llimit;i--){
int j;
for(j=i;j>=llimit;j--){
int product=i*j;
if(product<mproduct)
break;
int number=product;
int reverse=0;
while (number!=0){
reverse = reverse*10+number%10;
number/=10;
}
if(product==reverse && product>mproduct){
mproduct=product;
}
}
return mproduct;
}
}
int main(){
int n;
printf("Please enter two or three: %d\n",n);
Lab5(n);
return 0;
}

