#include <stdio.h>
int main(){
char inputString [25];
printf("Enter input \n");
scanf("%s", inputString);
printf("You have entered %s\n", inputString);
return 0;
}
