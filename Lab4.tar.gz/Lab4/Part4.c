#include<stdio.h>
int main(){
int sum=0;
int i;
for(i=0;i<1000;i=i+1){
if((i%5==0)||(i%3==0)){
sum=sum+i;
}
}
printf("%d\n",sum);
getchar();
return 0;
}
