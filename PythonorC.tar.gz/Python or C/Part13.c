#include <stdio.h>
int main(){
	FILE *fp = fopen("test.bin","r");
	if (fp ==NULL){
		return 0;
	}
	char c = fgetc(fp);
	if (feof(fp)){
		break;
		printf("%c",c);
	}
	while (1);
	fclose(fp);
	return(0);
	}
