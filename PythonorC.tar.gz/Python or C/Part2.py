import binascii
inputFile="input_file_name"
with open(inputFile,'rb') as fileObject:
	hexData = binascii.hexlify(fileObject.read())
	print(hexData)
outputFile = "output_file_name"
with open(outputFile, 'w') as fileObject2:
	fileObject2.writelines(hexData)
