#include<stdio.h>
int main(){
	char ch;
	FILE *fpr,*fpw;
	fpr = fopen("test.bin","r");
	
	if (fpr==NULL){
		puts("Cannot be opened");
	}
	fpw=fopen("test.bin","w");
	if(fpw==NULL){
	puts("Cannot be opened");
	}
	while(1){
	ch = getc(fpr);
	if(ch==EOF)
		break;
	else
		fputc(ch,fpw);
}
	fclose(fpr);
	fclose(fpw);
	return 0;
}
