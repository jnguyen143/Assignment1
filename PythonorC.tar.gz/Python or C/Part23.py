def stringPrint(string,index):
	if index==len(string):
		print (''.join(string))
		return
	if string[index] ="?":
		string[index] = '0'
		print(string, index+1)

		string[index] = '1'
		print(string,index+1)

		string[index] = '?'
	else:
		print(string,index+1)
int main():
file_input=open("file_name","rb")
string = open("file_name.txt","wb");
stringPrint(string,0);
