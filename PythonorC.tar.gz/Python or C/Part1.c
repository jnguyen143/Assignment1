#include<stdio.h>
#include <stlib.h>
struct numStruc{
int x,y,z;
}

int main(){
	int counter;
	FILE *fptr;
	struct numStruc num ;
	ptr_myfile=fopen("test.bin","wb");
	if(!ptr_myfile){
		printf("Cannot open file.");
		return 1;
	}
	for (counter=1;counter<5;counter++){
		num.x = n;
		num.y = 5*n;
		num.z = 5*n+1;
		fwrite(&num,sizeof(struct numStruc),1,fptr);
	}
	fclose(fptr);
}
	
