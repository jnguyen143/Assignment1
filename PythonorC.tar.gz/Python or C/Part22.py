import sys

argv=sys.argv
argc=len(argv)

if(argc!=2):
	quit()
try:
	infile = open(argv[1],'rb')
except:
	print "%s is not found" %argv[1]
	quit()
outfile = open(raw_input("Output name: "),'wb')
a = [str(x)for x in infile.read().split()]
for i in a:
	outfile.write(chr(int(i,16)))
infile.close()
outfile.close()
