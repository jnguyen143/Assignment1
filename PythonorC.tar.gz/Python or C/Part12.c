#include <stdio.h>
#include <stdlib.h>

struct numStruc{
	int x,y,z;
}
int main(){
	int n;
	struct numStruc num;
	FILE *fptr;

	if ((fptr = fopen("test.bin","rb")) == NULL){
		printf("Cannot open file.");
		return 1;
	}
	for(n=1;n<5;n++){
		fread(&num,sizeof(struct numStruc),1,fptr);
		printf("x: %d\ty: %d\tz: %d", num.x,num.y,num.z);
	}
	fclose(fptr);
	return 0;
}

