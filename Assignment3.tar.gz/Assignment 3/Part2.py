import sys

def countChar(data, ch):
	string = ''
	for line in data:
		string += line
		count = 0
	for c in string:
		if c == ch:
			count += 1
	return count

def countChars(data):
	for i in range(0, 26):
		count = countChar(data, chr(ord('a') + i))
	print('count of ' + chr(ord('a') + i) + ' is ' + str(count))

def Main():
	key = sys.argv[1]
	inputFile = sys.argv[2]
	outputFile = sys.argv[3]
	with open(inputFile, 'r') as f:
		data = f.readlines()
		data = [x.strip('\n') for x in data]
	countChars(data)
	out = open(outputFile, 'w')
	outputData = []
	for line in data:
		outline = ''
	for ch in line:
		if ch.isupper():
			ch = ch.lower()
		if ch.isalpha():
			ch = chr(ord('a') + (ord(ch) - ord('a') + key) % 26)
	outline = outline + ch
	outline = outline + '\n'
	outputData.append(outline)
	out.writelines(outputData)
	out.close()
