n=0
for i in range(1,1000):
	if not i% 5 or not i%3:
		n=n+i
print(n)

