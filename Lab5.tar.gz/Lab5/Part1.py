firstname = raw_input("Enter your first name: ")
print("Hello, " + firstname)

