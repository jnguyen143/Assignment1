age=input("Enter your age: ")
user_age=int(age)
print(user_age)

