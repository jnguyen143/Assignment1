#include <sys/stat.h> 
#include <sys/types.h>
#include <stdio.h> 
  
int main(){
	mkdir("/home/jnguyen143/Final/FINALc",0777);
	mkdir("/home/jnguyen143/Final/FINALc/copies",0777);
	mkdir("/home/jnguyen143/Final/FINALc/encrypted",0777);
	mkdir("/home/jnguyen143/Final/FINALc/decrypted",0777);
	FILE *fin=fopen("Part2.c","r");
	FILE*fout=fopen("/home/jnguyen143/Final/FINALc/Part2.c","w");
printf("Directory created\n");
}

