import shutil
import os
import glob
with open("/home/jnguyen143/Final/FINALinstruction",'r') as fp:
	nameList=fp.readlines()
fileInput = "/home/jnguyen143/Final"
output = "/home/jnguyen143/Final/FINALpython/copies"
outputc="/home/jnguyen143/Final/FINALc/copies"
path = "/home/jnguyen143/Final"
files = ['FINALinstruction','a.out','Part1.py','Part2.c']
for name in files:
	file_path=os.path.join(fileInput,name)
	for file_path in files:
		dest_path=os.path.join(output,name)
		dest_pathC=os.path.join(outputc,name)
		shutil.copy(file_path,dest_path)
		shutil.copy(file_path,dest_pathC)
print("Files copied into copies folder in FINALpython")
print("Files copied into copies folder in FINAALc")

	
