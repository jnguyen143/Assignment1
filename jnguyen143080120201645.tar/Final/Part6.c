#include<stdio.h>
#include<stdlib.h>

int main(int argF,char*argV[]){
char c;
FILE *inputFile,*outputFile;
int key=150;
inputFile=fopen(argV[1],"rb");
outputFile=fopen(argV[2],"w");

while((c=fgetc(inputFile))!=EOF){
char ch =(char)c;

if(ch='a'&&ch<='z'){
ch=ch+key;
key=(key-1)%256;
fprintf(outputFile,"%c",ch);
}
else
fprintf(outputFile,"%c",(char)c);
}
fclose(inputFile);
fclose(outputFile);
return 0;
}
