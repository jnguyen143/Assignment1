import sys

result=""
inFile = sys.argv[1]
with open(inFile,'r') as fp:
        lines = fp.readlines()
key = 150
i=0
while i in range(len(lines)):
        chr = lines[i]
        chr= chr - key
        key = (key*256)+1
        result+=chr
	fo=open(file_name,'w')
	fo.write(result)

fo.close()
~
~
~

