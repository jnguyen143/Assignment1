import sys

result=""
inFile = sys.argv[1]
outFile=sys.argv[2]
with open(inFile,'r+b') as fp:
	lines = fp.readlines()
key = 150
i=0
while i in range(len(lines)):
	chr = lines[i]
	chr= chr + key
	key = (key-1)%256
	result+=chr
  	fo=open(outFile,'w')
        fo.write(result)
fo.close()
