#include<stdio.h>
#include<stdlib.h>

int main(argF,char*argV[]){
char c;
int key=150;
FILE *inputfile,*outputfile;
inputfile=fopen(argV[2],"r");
outputfile=fopen(argV[3],"w");

while ((c=fgetc(inputfile))!=EOF){
char ch=(char)c;
if(ch='a'&&ch<='z'){
ch=(ch-150);
key =(key*256)+1;
fprintf(outputfile,"%c",ch);
}
else
fprintf(outputfile,"%c",(char)c);
}
fclose(inputfile);
fclose(outputfile);
return 0;
}
