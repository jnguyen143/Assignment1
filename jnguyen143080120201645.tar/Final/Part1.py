import os
import sys
import shutil

path=os.getcwd()
py_path=os.path.join(path,'FINALpython')
print ("The current working directory is %s" %path)
subdirectories = ['copies','encrypted','decrypted']

try:
 os.mkdir(py_path)
except OSError:
 print ("Failed to create directory %s" %py_path)
else:
 print("Created directory %s" %py_path)
 try:
  for folder in subdirectories:
    os.mkdir(os.path.join(py_path,folder))
 except OSError:
  print ("Failed to create directories %s" %py_path)
 else:
  print("Created directories %s" %py_path)
  try:
   current_name=sys.argv[0]
   script_path=os.path.join(path,current_name)
   shutil.copy(script_path,py_path)
  except OSError:
   print("Copy failed")
  else:
   print("Copy successful")
