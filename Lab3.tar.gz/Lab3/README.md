In order to even start the lab, bringing the 4HKD.pdb file from the directory into the personal directory was required with the command 'cp /home/cumoja1/3320/4HKD.pdb /home/jnguyen143/Lab3/4HKD.pdb'. 

In order to find the headers that weren't associated with the certain terms, the command 'grep -v -E 'ATOM|CONECT\HETAM\TER\END' 4HKD.pdb' was used to only bring up the header forms that weren't referred to in the command. 

For replacing HETAM with ATOM and MSE with MET, the sed command 'sed 's/HETATM/ATOM  /g;s/MSE/MET/g' 4HKD.pdb' was used to carry out the operation, with the results being saved under a new file new4HKD.pdb.

 In order to find the maximum value of x of ATOM, the awk command 'awk 'BEGIN {a=0}{if($1=="ATOM"&&$7>0+a) a=$7} END{print "max: " a)' 4HKD.pdb, where $7 represents the x value within the system. The same command was used for finding the maximum value of y and z but instead replacing $7 with $8 and $9 for y and z respectively. A similar process was used to find the minimums of x, y, and z with the auk command 'awk 'BEGIN {a=0}{if($1=="ATOM"&&7<0+a)a=$7} END{print "max: " a}' 4HKD.pdb, with $7 being replaced by $8 and $9 when finding the minimum of y and z.

To find the average of the x value of HETATM, the auk command 'awk 'BEGIN {sum=0} {if($1=="HETATM") sum+=$7} END{print "average: " sum/NR}' 4HKD.pdb,' with $7 again being replaced by $8 and $9 to find the averages of the the y and z values.

Replacing HOH with WAT required the use of the sed command 'sed 's/HOH/WAT/g' 4HKD.pdb,' with the result being saved under a new file WAT4HKD.pdb

In order to sort the ATOM entries by the 11th value, the grep command 'grep 'ATOM'|sort -nk11 4HKD.pdb', with the newly sorted file results being saved under ATOM4HKD.pdb.
